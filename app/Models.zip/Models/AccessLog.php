<?php

namespace App\Models;

use App;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AccessLog extends MasterModel {
    use SoftDeletes;
     protected $fillable = ['sender_id','receiver_id','request_id','service_name','amount','negotiate','veriable_type','currency_code','updated_at','created_at'];
}
}