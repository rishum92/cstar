<?php

namespace App\Models;

use App;
use Auth;

use Illuminate\Database\Eloquent\Model;

class serviceProvider extends MasterModel {
	 protected $table = 'user_twit_details';
}
