'use strict';

var app = angular.module('CasualStar', [
    'RegisterCtrl',
    ], function($interpolateProvider) {
      $interpolateProvider.startSymbol('[[');
      $interpolateProvider.endSymbol(']]');
});
