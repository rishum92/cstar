@extends('layouts.master')

@section('meta')
  <title>About | CasualStar</title>
@endsection

@section('scripts')
  
@endsection

@section('content')
  <section class="main collection-main contact-main">
    <div class="wrap wrap-flex block-flex vertical-center-flex">
      <div class="description">
        <h1>A little bit about us</h1>
        <p>CasualStar.UK is a new and fun fetish platform that brings like minded adults together. Our platform is FREE to join. We aim to provide a Findom service that is safe, profitable and fulfilling for all involved, delivered by a system which is user friendly and very easy to understand.<p>
          <br>
        <p>CasualStar.uk is a British based, online only establishment with a worldwide appeal.  Our primary target audience consist of femdoms and Paypigs with an active interest in financial dominatrix. All countries, races, and cultures are welcomed to join.</p>
<br>
        <p>We do not tolerate anything outside of what this platform is intended for; nor can we accept any liability for any misuse of our platform by groups or individuals that may cause a member of our platform to suffer any form of abuse or any other type of misfortune. However we do take abuse on our platform (CasualStar.UK) seriously and in any such case where abuse is brought to our attention, a prompt and full investigation will be carried out. Any members found to be causing abuse will be completely blocked, and permanently removed from accessing our services.  By registering to use CasualStar.uk you have automatically agreed to our Terms and Conditions, which can be found in the footer of this page/ website.</p>
<br>
<br>
        <p>Our platform CasualStar.UK is strictly intended for those 18 (eighteen) years of age and older.</p>
.</p>
      </div>
    </div>
  </section>
  {!! Form::close() !!}
@endsection