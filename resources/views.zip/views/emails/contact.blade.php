<!DOCTYPE html>
<html lang="{{ App::getLocale() }}">
        <head>
                <meta charset="utf-8">
        </head>
        <body>
                <h3>CasualStar: New message received</h3>
                <p>{{ $emailMessage }}</p>
        </body>
</html>
