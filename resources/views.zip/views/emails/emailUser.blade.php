<!DOCTYPE html>
<html lang="{{ App::getLocale() }}">
    <head>
    	<meta charset="utf-8">
    </head>
    <body>
        <h3>New message from CasualStar:</h3>
        <p>{{ $messageText }}</p>
    </body>
</html>
