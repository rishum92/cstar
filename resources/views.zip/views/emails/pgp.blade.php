<!DOCTYPE html>
<html lang="{{ App::getLocale() }}">
        <head>
                <meta charset="utf-8">
        </head>
        <body>
                <h3>CasualStar: New message received</h3>
                <!-- <p>{{ $emailMessage }}</p> -->
                <p>Hello <b>{{ $emailMessage }}</b><br/>
Congratulations, you have reached 1000 Private Gallery Points (PGP), which means you are now able
to gain access to all private galleries throughout our website. Please login to activate and begin your
24 hours of free access. Once logged in you will find the activation controls at the bottom of your
Activity page.<br/><br/>

Kind regards,<br/><br/> Casualstar.uk</p>
        </body>
</html>
