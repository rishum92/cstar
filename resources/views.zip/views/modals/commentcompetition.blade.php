
<div class="modal fade" id="viewPhotoModal" tabindex="-1" role="dialog" aria-labelledby="viewPhotoModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      [[viewPhoto['data'].user_id]]
    </div>
  </div>
</div>
