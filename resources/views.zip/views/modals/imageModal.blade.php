
<div class="modal fade" id="imageModalId" tabindex="-1" role="dialog" aria-labelledby="addPhotoModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
     hhh
    </div>
  </div>
</div>

