<div class="modal fade" id="myofferpost" role="dialog">
              <div class="modal-dialog">
              <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">My offer post</h4>
                  </div>
                  <div class="modal-body" id="interested_model_id">
                    <div class="row"> 
                    <div class="col-md-12">
                        <div> 
                          <img class="view_pro_pic" src="img/59ce3646d240c.png" />
                        </div>
                        <div class="view_users_link">
                           <h3><a href="#" class="view_users_link"><span>username</span></a></h3>

                        </div> 
                        <div class="my_offer_date"> 
                          <span>14/03/2019</span>
                        </div>
                        <div class="my_offer_msg">
                          <span class="label label-danger" data-toggle="modal" data-target="#message">
                            <i class="fa fa-paper-plane"></i> Message
                          </span>

                          <!-- popup message start -->
                            <div class="modal fade" id="message" role="dialog">
                                <div class="modal-dialog">
                                
                                  <!-- Modal content-->
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      <h4 class="modal-title">Send message</h4>
                                    </div>
                                    <div class="modal-body">
                                       <div class="form-group">
                                        <label for="comment">Comment:</label>
                                        <textarea class="form-control"  id="comment">
                                          
                                        </textarea>
                                      </div>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                  </div>
                                  
                                </div>
                              </div>
                          <!-- popup message close -->
                          
                        </div>
                     </div>
                  </div>
                  </div>
                    <div class="modal-footer">
                      <button type="button" id="refreshdata" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
            </div>