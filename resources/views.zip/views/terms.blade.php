@extends('layouts.master')

@section('meta')
  <title>Terms &amp; Conditions » CasualStar</title>
@endsection

@section('scripts')
  
@endsection

@section('content')
  <section class="main collection-main contact-main">
    <div class="wrap wrap-flex block-flex vertical-center-flex">
      <div class="description">
        <h1>Terms &amp; Conditions</h1>
        <p>
          Please find our Terms &amp; Conditions attached:<br>
          <a href="{{ URL::asset('docs/CasualstarTerms&Conditions2017.docx') }}"><i class="fa fa-file-pdf-o"></i> Terms_and_Conditions.docx</a>
        </p>
      </div>
    </div>
  </section>
  {!! Form::close() !!}
@endsection